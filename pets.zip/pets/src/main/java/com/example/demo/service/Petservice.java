package com.example.demo.service;

import java.util.List;

import com.example.demo.entities.pets;

public interface Petservice {
	pets savePets(pets pet);
	pets updatePets(pets pet);
	void deletePets(pets pet);
	void deletePetById(Long id);
	pets getPet(Long id);
	List<pets> getAllPets();

}
