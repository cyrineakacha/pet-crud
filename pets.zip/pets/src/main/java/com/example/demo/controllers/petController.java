package com.example.demo.controllers;

import java.text.ParseException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.entities.pets;
import com.example.demo.service.Petserviceimp;

@Controller
public class petController {

	@Autowired
	Petserviceimp Petservice;
	@RequestMapping("/showCreate")
	public String showCreate()
	{
	return "createPet";
	
	}
	@RequestMapping("/savePets")
	public String savePets(@ModelAttribute("pets") pets pets,
	 ModelMap modelMap) throws
	ParseException
	{
	pets savepet = Petservice.savePets(pets);
	String msg ="animal enregistré avec Id "+ savepet.getIdepet();
	modelMap.addAttribute("msg", msg);
	return "createPet";
	}
	@RequestMapping("/ListePets")
	public String ListePets(ModelMap modelMap)
	{
	List<pets> pets = Petservice.getAllPets();
	modelMap.addAttribute("pets", pets);
	return "ListePets";
	}
	
	@RequestMapping("/supprimerPet")
	public String supprimerPet(@RequestParam("id") Long id,
	 ModelMap modelMap)
	{
	Petservice.deletePetById(id);
	List<pets> pets = Petservice.getAllPets();
	modelMap.addAttribute("pets", pets);
	return "ListePets";
	}

	
	@RequestMapping("/modifierPet")
	public String editerPet(@RequestParam("id") Long id,ModelMap modelMap)
	{
		pets  p= Petservice.getPet(id);
		modelMap.addAttribute("pets", p);
		return "editerPet";
	}
	@RequestMapping("/updatePet")
	public String updatePet(@ModelAttribute("pet") pets pet , ModelMap modelMap)
	{

		Petservice.updatePets(pet);
		List<pets> pets = Petservice.getAllPets();
		modelMap.addAttribute("pets", pets);
		return "ListePets";
		}
}
