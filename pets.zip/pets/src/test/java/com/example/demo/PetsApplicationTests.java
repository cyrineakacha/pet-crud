package com.example.demo;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import com.example.demo.entities.pets;
import com.example.demo.repos.PetsRepository;

@SpringBootTest
class PetsApplicationTests {

	@Autowired
	private PetsRepository petRepository;
	

	@Test
	public void testCreateProduit() {
	pets pets = new pets("wshifa","cat","siamois",70);
	petRepository.save(pets);
	}
	
	@Test
	public void testFindPet()
	{
	pets pet = petRepository.findById(1L).get();
	System.out.println(pet);
	}
	
	@Test
	public void testUpdatePet()
	{
		pets pet = petRepository.findById(1L).get();
		pet.setPrixpet(120);
		petRepository.save(pet);
	}
	 
	@Test
	public void testDeletePet()
	{
		petRepository.deleteById(1L);;
	}
	
	@Test
	public void testListerTousPet()
	{
	List<pets> pets = petRepository.findAll();
	for (pets pe : pets)
	{
	System.out.println(pe);
	}
	}
}
